/**
 * Created by lzhan on 2017/3/2.
 */
var booksAll=[
    {
        name:'浮生六计',
        author:'汪涵',
        price:22.8,
        comments:223000,
        sall_type:0,
        icon:'book01.jpg'
    },
    {
        name:'三国演义',
        author:'罗贯中',
        price:1.0,
        comments:122300,
        sall_type:1,
        icon:'book01.jpg'
    },
    {
        name:'西游记',
        author:'吴承恩',
        price:122.8,
        comments:823000,
        sall_type:0,
        icon:'book01.jpg'
    },
    {
        name:'水浒传',
        author:'施耐庵2号',
        price:222.8,
        comments:245000,
        sall_type:1,
        icon:'book01.jpg'
    },
    {
        name:'在水一方',
        author:'施耐庵',
        price:222.8,
        comments:245000,
        sall_type:0,
        icon:'book01.jpg'
    },
    {
        name:'红楼梦',
        author:'曹雪芹',
        price:52.8,
        comments:223000,
        sall_type:1,
        icon:'book01.jpg'
    }
];
var lastBooks=[];
var page_books=4;

showBooks(booksAll);
displayIndex(booksAll);

var bookContainer=document.getElementById('bookContainer');
function showBooks(books) {
    bookContainer.innerHTML='';
    for(var i=0;i<books.length;i++){
        bookContainer.innerHTML=bookContainer.innerHTML+'<div class="book-css">' +
            '<div class="book-icon-css">' +
            '<img src="images/'+books[i].icon+'" alt="">' +
            '</div>' +
            '<div class="book-price-css">' +
            '<span class="money">￥</span>' +
            '<span>' +
            books[i].price +
            '</span>' +
            '</div>' +
            '<div class="book-author-css">' +
            '作者 '+books[i].author +
            '</div>' +
            '<div class="book-comment-css">' +
            '已有' +
            ' <a href="#">'+books[i].comments+'</a>' +
            '个评价' +
            '</div>' +
            '<div class="book-type-css">' +
            ' 京东自营' +
            '</div>' +

            '</div>'
    }


}

function searchBooks() {
    lastBooks=[];
    var searchText=document.getElementById('txtSearch').value.trim();


    if(searchText.length==0){
        showBooks(booksAll);
        displayIndex(booksAll);
        // return;

    }else{
        for(var i=0;i<booksAll.length;i++){
            if(booksAll[i].name.indexOf(searchText)!=-1){
                lastBooks.push(booksAll[i]);
            }
        }
        showBooks(lastBooks);
        displayIndex(lastBooks);

    }


}

function searchBooksByType(t) {

    lastBooks=[];
    for(var i=0;i<booksAll.length;i++){
        if(booksAll[i].sall_type==t){
            lastBooks.push(booksAll[i]);
        }
    }
    showBooks(lastBooks);

    displayIndex(lastBooks);
}


var divFooter=document.getElementById('div_footer');



function displayIndex(books) {
    var page_count=Math.ceil(books.length/page_books);

    divFooter.innerHTML='';
    for(var i=0;i<page_count;i++){
        divFooter.innerHTML=divFooter.innerHTML+"<a href='#'>"+(i+1)+"</a>"
    }
}



